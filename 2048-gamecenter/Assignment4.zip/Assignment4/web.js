// web.js
// Express & Mongo initialization
var express = require('express');
var mongo = require('mongodb');

var app = express();
app.use(express.json());
app.use(express.urlencoded());
app.use(express.bodyParser());
app.set('title', 'nodeapp');


var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter';

var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

app.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS')
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
 });


app.get('/', function (request, response) {
	
	var hypertext = "<!DOCTYPE HTML><html><head><title>2048 GameCenter</title></head><body><h1>2048 GameCenter</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";
	db.collection('scores', function(er, collection){
		
		collection.find().sort({score: -1}).limit(100).toArray(function(err, cursor){
			if(!err){
				
				
				for(var i = 0; i < cursor.length; i++){
					
					hypertext +="<tr><td>" + cursor[i].username + "</td><td>" + cursor[i].score + "</td><td>" + cursor[i].created_at + "</td></tr>";
				}
				
				hypertext += "</table></body></html>";
				response.send(hypertext);
			}
		});
	});
});

app.post('/submit.json', function(request, response){
	user = request.body.username;
	scr = request.body.score;
	grd = request.body.grid;
	tme = request.body.created_at;
	array = {username: user, score: scr, grid: grd, created_at: tme};

	db.collection('scores', function (error, collection){
		if(!error){
			collection.insert(array, function(error, saved){
				response.send("Your data is in the bin!");
			});
		}
		else{
			response.send("Not an appropriate data set!");
		}
	});
});

app.get('/scores.json', function(request, response){

	var hypertext = "<!DOCTYPE HTML><html><head><title>2048 GameCenter</title></head><body><h1>2048 GameCenter</h1><table><tr><th>User</th><th>Score</th><th>Timestamp</th></tr>";
	db.collection('scores', function(er, collection){
		
		collection.find().sort({score:-1}).limit(100).toArray(function(err, cursor){
			if(!err){	
				for(var i = 0; i < cursor.length; i++){
					if(cursor[i].username == "diglio01"){
						hypertext +="<tr><td>" + cursor[i].username + "</td><td>" + cursor[i].score + "</td><td>" + cursor[i].created_at + "</td></tr>";
					}
				}
				
				hypertext += "</table></body></html>";
				response.send(hypertext);
			}
		});
	});
});



var port = Number(process.env.PORT || 3000);
app.listen(port, function() {
  console.log("Listening on " + port);
});
