//2048 GameCenter
//Written by: Dave Igliozzi
//For: Comp 20 - Web Programming

//What has been implemented correctly:
//I have properly stored data from the 2048 game into the mongolab database
//I have properly accepted the data in the post funtion with /submit.json


//What has not been implemented correctly:


//Hours spent completing this assignment: ~ 
//probably around 12-15 hours



//The modifications:
//I added a line of jQuery and a function that retrieves the date to the game_manager.js file in the 2048 game.
//I also added a script tag to the index.html page for 2048 to enable jQuery in the 2048 game.